#pragma once

namespace flecs {

using Rest = EcsRest;

namespace rest {

namespace _ {

void init(flecs::world& world);

}
}
}
